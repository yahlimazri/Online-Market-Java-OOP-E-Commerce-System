package ShaharAndYahli;

public interface IterationListener {

    void onIterationEnded(String message);
}
