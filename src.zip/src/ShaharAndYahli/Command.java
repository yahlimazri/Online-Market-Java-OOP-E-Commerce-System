package ShaharAndYahli;

public interface Command {
    void execute();
}
